"use client";

import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useCardStore } from "@/lib/cardStore";
import { Calendar, MapPin, Building2, Globe, Type, Hash } from "lucide-react";

export function EventHeaderEditor() {
  const {
    card, setEventName, setTagline, setDate, setVenue,
    setCity, setState, setCountry, setPromotion,
  } = useCardStore();

  return (
    <div className="rounded-lg border border-white/10 bg-[#0c0c0c]/80 backdrop-blur p-4 ufc-card-grain">
      <div className="flex items-center justify-between mb-3">
        <h2 className="ufc-headline text-sm tracking-wider text-white flex items-center gap-2">
          <Type className="h-4 w-4 text-[#d20a0a]" />
          Event Details
        </h2>
        <span className="ufc-tag bg-white/5 text-white/60">META</span>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <Field label="Event Name" icon={<Hash className="h-3 w-3" />} full>
          <Input
            value={card.eventName}
            onChange={(e) => setEventName(e.target.value)}
            placeholder="UFC 312"
            className="bg-black/40 border-white/10 text-white font-bold focus:border-[#d20a0a]"
          />
        </Field>

        <Field label="Tagline" icon={<Type className="h-3 w-3" />} full>
          <Input
            value={card.tagline || ""}
            onChange={(e) => setTagline(e.target.value)}
            placeholder="Title Unification / Bad Blood / etc."
            className="bg-black/40 border-white/10 text-white focus:border-[#d20a0a]"
          />
        </Field>

        <Field label="Date" icon={<Calendar className="h-3 w-3" />}>
          <Input
            type="date"
            value={card.date}
            onChange={(e) => setDate(e.target.value)}
            className="bg-black/40 border-white/10 text-white ufc-mono focus:border-[#d20a0a]"
          />
        </Field>

        <Field label="Promotion" icon={<Globe className="h-3 w-3" />}>
          <Input
            value={card.promotion}
            onChange={(e) => setPromotion(e.target.value)}
            placeholder="UFC"
            className="bg-black/40 border-white/10 text-white font-bold focus:border-[#d20a0a]"
          />
        </Field>

        <Field label="Venue" icon={<Building2 className="h-3 w-3" />} full>
          <Input
            value={card.venue}
            onChange={(e) => setVenue(e.target.value)}
            placeholder="T-Mobile Arena"
            className="bg-black/40 border-white/10 text-white focus:border-[#d20a0a]"
          />
        </Field>

        <Field label="City" icon={<MapPin className="h-3 w-3" />}>
          <Input
            value={card.city}
            onChange={(e) => setCity(e.target.value)}
            placeholder="Las Vegas"
            className="bg-black/40 border-white/10 text-white focus:border-[#d20a0a]"
          />
        </Field>

        <Field label="State / Region" icon={<MapPin className="h-3 w-3" />}>
          <Input
            value={card.state || ""}
            onChange={(e) => setState(e.target.value)}
            placeholder="NV"
            className="bg-black/40 border-white/10 text-white focus:border-[#d20a0a]"
          />
        </Field>

        <Field label="Country" icon={<Globe className="h-3 w-3" />} full>
          <Input
            value={card.country}
            onChange={(e) => setCountry(e.target.value)}
            placeholder="USA"
            className="bg-black/40 border-white/10 text-white focus:border-[#d20a0a]"
          />
        </Field>
      </div>
    </div>
  );
}

function Field({
  label, icon, children, full,
}: {
  label: string;
  icon?: React.ReactNode;
  children: React.ReactNode;
  full?: boolean;
}) {
  return (
    <div className={full ? "sm:col-span-2" : ""}>
      <Label className="flex items-center gap-1.5 text-[10px] uppercase tracking-widest text-white/50 mb-1">
        {icon}
        {label}
      </Label>
      {children}
    </div>
  );
}
