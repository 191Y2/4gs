"use client";

import { useMemo } from "react";
import { FIGHTERS } from "@/lib/fighters";
import { WEIGHT_CLASSES } from "@/lib/weightClasses";
import { Users, Crown, Star } from "lucide-react";

export function RosterStats() {
  const stats = useMemo(() => {
    const byWc = WEIGHT_CLASSES.map((wc) => {
      const list = FIGHTERS.filter((f) => f.weightClass === wc.id);
      const champ = list.filter((f) => f.isChampion).length;
      const ranked = list.filter((f) => f.rank && f.rank > 0).length;
      return { wc, total: list.length, champ, ranked };
    });
    return {
      total: FIGHTERS.length,
      champs: FIGHTERS.filter((f) => f.isChampion).length,
      ranked: FIGHTERS.filter((f) => f.rank && f.rank > 0).length,
      byWc,
    };
  }, []);

  return (
    <div className="rounded-lg border border-white/10 bg-[#0c0c0c]/80 backdrop-blur p-4 ufc-card-grain">
      <div className="flex items-center justify-between mb-3">
        <h2 className="ufc-headline text-sm tracking-wider text-white flex items-center gap-2">
          <Users className="h-4 w-4 text-[#d20a0a]" />
          Roster Browser
        </h2>
        <span className="ufc-tag ufc-red-grad text-white">LIVE</span>
      </div>

      {/* Top stats */}
      <div className="grid grid-cols-3 gap-2 mb-3">
        <div className="rounded border border-white/10 bg-black/40 px-2 py-2 text-center">
          <div className="text-[9px] uppercase tracking-widest text-white/40">Roster</div>
          <div className="ufc-mono text-xl font-black text-white">{stats.total}</div>
        </div>
        <div className="rounded border border-[#e8c46a]/30 bg-[#e8c46a]/5 px-2 py-2 text-center">
          <div className="text-[9px] uppercase tracking-widest text-white/40 flex items-center justify-center gap-1">
            <Crown className="h-2.5 w-2.5" /> Champs
          </div>
          <div className="ufc-mono text-xl font-black text-[#e8c46a]">{stats.champs}</div>
        </div>
        <div className="rounded border border-[#d20a0a]/30 bg-[#d20a0a]/5 px-2 py-2 text-center">
          <div className="text-[9px] uppercase tracking-widest text-white/40 flex items-center justify-center gap-1">
            <Star className="h-2.5 w-2.5" /> Ranked
          </div>
          <div className="ufc-mono text-xl font-black text-[#ff6666]">{stats.ranked}</div>
        </div>
      </div>

      {/* Per-weight-class breakdown */}
      <div className="space-y-1.5 max-h-[400px] overflow-y-auto ufc-scroll-thin pr-1">
        {stats.byWc.map(({ wc, total, champ, ranked }) => (
          <div
            key={wc.id}
            className="rounded border border-white/5 bg-black/40 px-2.5 py-1.5 hover:border-[#d20a0a]/30 transition-colors"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 min-w-0">
                <span className="text-[10px] font-black text-[#d20a0a] ufc-mono w-10 shrink-0">{wc.shortName}</span>
                <span className="text-[11px] text-white/80 truncate" title={wc.name}>{wc.name}</span>
              </div>
              <div className="flex items-center gap-1.5 ufc-mono text-[10px]">
                {champ > 0 && (
                  <span className="text-[#e8c46a]" title="Champion">★{champ}</span>
                )}
                {ranked > 0 && (
                  <span className="text-white/60" title="Ranked">#15</span>
                )}
                <span className="text-white font-bold">{total}</span>
                <span className="text-white/30 text-[9px]">{wc.limit}lb</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
