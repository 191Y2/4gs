"use client";

import { Plus, X, Crown } from "lucide-react";
import { Fighter } from "@/lib/types";
import { getWeightClass } from "@/lib/weightClasses";
import { flagEmoji } from "@/lib/cardStore";

interface FighterSlotProps {
  label: string;
  color: "red" | "blue";
  fighter: Fighter | null;
  onPick: () => void;
  onClear: () => void;
}

export function FighterSlot({ label, color, fighter, onPick, onClear }: FighterSlotProps) {
  const accent = color === "red" ? "#d20a0a" : "#3b82f6";
  const initials = fighter?.name
    .split(" ")
    .map((p) => p[0])
    .slice(0, 2)
    .join("") ?? "";

  return (
    <div
      className="relative rounded-md border bg-black/40 overflow-hidden min-h-[160px] flex flex-col"
      style={{ borderColor: fighter ? accent : "rgba(255,255,255,0.1)" }}
    >
      <div
        className="flex items-center justify-between px-3 py-1.5"
        style={{ background: `linear-gradient(90deg, ${accent}40, transparent)` }}
      >
        <span
          className="text-[10px] font-black tracking-widest"
          style={{ color }}
        >
          {label}
        </span>
        {fighter && (
          <button
            onClick={onClear}
            className="text-white/40 hover:text-white text-xs"
            title="Clear"
          >
            <X className="h-3.5 w-3.5" />
          </button>
        )}
      </div>

      {fighter ? (
        <div className="flex-1 p-3 flex flex-col items-center justify-center text-center">
          <div
            className="flex h-14 w-14 items-center justify-center rounded-full font-black text-white mb-2"
            style={{
              background: fighter.isChampion
                ? "linear-gradient(135deg, #e8c46a 0%, #8b6e2a 100%)"
                : `linear-gradient(135deg, ${accent} 0%, #1a1a1a 100%)`,
              boxShadow: `0 0 0 2px ${accent}80`,
            }}
          >
            {initials}
          </div>
          <div className="flex items-center gap-1.5">
            <h3 className="text-sm font-extrabold text-white leading-tight">
              {fighter.name}
            </h3>
            {fighter.isChampion && (
              <Crown className="h-3 w-3 text-[#e8c46a]" />
            )}
          </div>
          {fighter.nickname && (
            <p className="text-[11px] italic text-white/60">&ldquo;{fighter.nickname}&rdquo;</p>
          )}
          <div className="mt-1 flex items-center gap-2 text-[10px] text-white/60">
            <span>{flagEmoji(fighter.countryCode)}</span>
            <span className="ufc-mono font-bold text-white">
              {fighter.record.wins}-{fighter.record.losses}-{fighter.record.draws}
            </span>
            {fighter.rank && (
              <span className="ufc-mono text-[#e8c46a]">#{fighter.rank}</span>
            )}
          </div>
          <div className="mt-1 text-[10px] uppercase tracking-wider text-white/40">
            {getWeightClass(fighter.weightClass)?.shortName} · {fighter.style}
          </div>
          {fighter.winMethod && (
            <div className="mt-1.5 flex items-center gap-2 text-[9px] ufc-mono text-white/70">
              <span className="text-[#ff8888]">{fighter.winMethod.ko}KO</span>
              <span className="text-[#88ccff]">{fighter.winMethod.sub}SUB</span>
              <span className="text-white/60">{fighter.winMethod.dec}DEC</span>
            </div>
          )}
        </div>
      ) : (
        <button
          onClick={onPick}
          className="flex-1 flex flex-col items-center justify-center text-white/40 hover:text-white hover:bg-white/[0.03] transition-colors"
        >
          <div
            className="flex h-14 w-14 items-center justify-center rounded-full border-2 border-dashed mb-2"
            style={{ borderColor: `${accent}60` }}
          >
            <Plus className="h-6 w-6" style={{ color: accent }} />
          </div>
          <span className="text-xs font-bold uppercase tracking-widest">
            Pick Fighter
          </span>
          <span className="text-[10px] text-white/30 mt-0.5">
            Browse roster
          </span>
        </button>
      )}
    </div>
  );
}
