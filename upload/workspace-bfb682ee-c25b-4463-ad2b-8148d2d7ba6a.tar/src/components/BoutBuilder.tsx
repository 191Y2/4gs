"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Swords, Crown, Sparkles, ChevronRight, Star } from "lucide-react";
import { useCardStore } from "@/lib/cardStore";
import { Fighter, WeightClassId } from "@/lib/types";
import { WEIGHT_CLASSES, getWeightClass } from "@/lib/weightClasses";
import { FighterSlot } from "./FighterSlot";
import { FighterPicker } from "./FighterPicker";

export function BoutBuilder() {
  const {
    selectedFighterA, selectedFighterB,
    setSelectedA, setSelectedB,
    addBout,
    card,
  } = useCardStore();

  const [picking, setPicking] = useState<null | "A" | "B">(null);
  const [isFiveRounds, setIsFiveRounds] = useState(false);
  const [isTitle, setIsTitle] = useState(false);
  const [isFeatured, setIsFeatured] = useState(false);
  const [catchweight, setCatchweight] = useState<string>("");

  const excludeIds = card.bouts.flatMap((b) => [b.fighterA.id, b.fighterB.id]);
  const preferredWc =
    selectedFighterA?.weightClass || selectedFighterB?.weightClass;

  const handleSelect = (f: Fighter) => {
    if (picking === "A") setSelectedA(f);
    else if (picking === "B") setSelectedB(f);
    setPicking(null);
  };

  const canAdd = selectedFighterA && selectedFighterB;

  const handleAdd = () => {
    if (!canAdd) return;
    addBout({
      boutType: card.bouts.length === 0 ? "main-event" : "main-card",
      isFeatured,
      catchweight: catchweight ? parseInt(catchweight) : undefined,
      rounds: isFiveRounds || isTitle ? 5 : 3,
      titleBout: isTitle ? { type: "undisputed", weightClass: selectedFighterA!.weightClass } : undefined,
    });
    setIsFiveRounds(false);
    setIsTitle(false);
    setIsFeatured(false);
    setCatchweight("");
  };

  return (
    <div className="rounded-lg border border-white/10 bg-[#0c0c0c]/80 backdrop-blur p-4 ufc-card-grain">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Swords className="h-4 w-4 text-[#d20a0a]" />
          <h2 className="ufc-headline text-sm tracking-wider text-white">Bout Builder</h2>
        </div>
        <span className="ufc-tag bg-white/5 text-white/60">DRAFT</span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-[1fr_auto_1fr] gap-3 items-stretch">
        <FighterSlot
          label="RED CORNER"
          color="red"
          fighter={selectedFighterA}
          onPick={() => setPicking("A")}
          onClear={() => setSelectedA(null)}
        />

        <div className="flex md:flex-col items-center justify-center gap-2 py-2">
          <div className="text-[10px] font-black text-[#e8c46a] tracking-widest">VS</div>
          <div className="h-12 w-px md:w-12 md:h-px bg-gradient-to-r from-[#d20a0a] to-[#e8c46a]" />
        </div>

        <FighterSlot
          label="BLUE CORNER"
          color="blue"
          fighter={selectedFighterB}
          onPick={() => setPicking("B")}
          onClear={() => setSelectedB(null)}
        />
      </div>

      {/* Bout options */}
      <div className="mt-4 grid grid-cols-2 md:grid-cols-4 gap-3">
        <label className="flex items-center justify-between gap-2 rounded border border-white/10 bg-black/40 px-3 py-2 cursor-pointer hover:border-[#d20a0a]/40">
          <div className="flex items-center gap-1.5">
            <Crown className="h-3.5 w-3.5 text-[#e8c46a]" />
            <span className="text-[11px] font-bold text-white">Title Bout</span>
          </div>
          <Switch checked={isTitle} onCheckedChange={setIsTitle} />
        </label>

        <label className="flex items-center justify-between gap-2 rounded border border-white/10 bg-black/40 px-3 py-2 cursor-pointer hover:border-[#d20a0a]/40">
          <div className="flex items-center gap-1.5">
            <Sparkles className="h-3.5 w-3.5 text-[#d20a0a]" />
            <span className="text-[11px] font-bold text-white">5 Rounds</span>
          </div>
          <Switch checked={isFiveRounds} onCheckedChange={setIsFiveRounds} />
        </label>

        <label className="flex items-center justify-between gap-2 rounded border border-white/10 bg-black/40 px-3 py-2 cursor-pointer hover:border-[#d20a0a]/40">
          <div className="flex items-center gap-1.5">
            <Star className="h-3.5 w-3.5 text-[#e8c46a]" />
            <span className="text-[11px] font-bold text-white">Featured</span>
          </div>
          <Switch checked={isFeatured} onCheckedChange={setIsFeatured} />
        </label>

        <div className="rounded border border-white/10 bg-black/40 px-3 py-2">
          <Label className="text-[10px] uppercase tracking-wider text-white/40">Catchweight</Label>
          <Select value={catchweight || "none"} onValueChange={(v) => setCatchweight(v === "none" ? "" : v)}>
            <SelectTrigger className="h-6 mt-0.5 p-0 border-0 bg-transparent text-xs font-bold text-white">
              <SelectValue placeholder="None" />
            </SelectTrigger>
            <SelectContent className="bg-[#141414] border-white/10">
              <SelectItem value="none">None</SelectItem>
              {Array.from({ length: 30 }, (_, i) => 130 + i * 2).map((w) => (
                <SelectItem key={w} value={String(w)}>{w} lbs</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Add bout button */}
      <Button
        disabled={!canAdd}
        onClick={handleAdd}
        className="w-full mt-4 h-11 ufc-red-grad hover:opacity-90 text-white font-black tracking-widest ufc-button-press disabled:opacity-30 disabled:cursor-not-allowed"
      >
        <Plus className="h-4 w-4 mr-2" />
        ADD BOUT TO CARD
        <ChevronRight className="h-4 w-4 ml-2" />
      </Button>

      {!canAdd && (
        <p className="text-center text-[11px] text-white/40 mt-2">
          Pick two fighters to build a bout.
        </p>
      )}

      <FighterPicker
        open={picking !== null}
        onOpenChange={(v) => !v && setPicking(null)}
        title={picking === "A" ? "Select Red Corner" : "Select Blue Corner"}
        excludeIds={[...excludeIds, selectedFighterA?.id, selectedFighterB?.id].filter(Boolean) as string[]}
        preferredWeightClass={preferredWc}
        onSelect={handleSelect}
      />
    </div>
  );
}
