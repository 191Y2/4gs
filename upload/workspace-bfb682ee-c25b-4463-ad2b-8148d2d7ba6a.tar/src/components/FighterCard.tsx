"use client";

import { Fighter } from "@/lib/types";
import { getWeightClass } from "@/lib/weightClasses";
import { flagEmoji } from "@/lib/cardStore";

interface FighterCardProps {
  fighter: Fighter;
  onClick?: () => void;
  selected?: boolean;
  compact?: boolean;
}

export function FighterCard({ fighter, onClick, selected, compact }: FighterCardProps) {
  const wc = getWeightClass(fighter.weightClass);
  const initials = fighter.name
    .split(" ")
    .map((p) => p[0])
    .slice(0, 2)
    .join("");

  const record = `${fighter.record.wins}-${fighter.record.losses}-${fighter.record.draws}`;
  const koSub = fighter.winMethod ? `${fighter.winMethod.ko} KO / ${fighter.winMethod.sub} SUB` : "";

  if (compact) {
    return (
      <button
        type="button"
        onClick={onClick}
        className={`ufc-button-press w-full text-left rounded-md border px-3 py-2 transition-all
          ${selected
            ? "border-[#d20a0a] bg-[#d20a0a]/15 ufc-shadow-red"
            : "border-white/10 bg-[#141414] hover:border-[#d20a0a]/50 hover:bg-[#1f1f1f]"
          }`}
      >
        <div className="flex items-center gap-2">
          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full ufc-red-grad text-xs font-black text-white">
            {initials}
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-1.5">
              <span className="truncate text-sm font-bold text-white">
                {fighter.name}
              </span>
              {fighter.isChampion && (
                <span className="text-[#e8c46a]" title="Champion">★</span>
              )}
            </div>
            <div className="flex items-center gap-2 text-[10px] text-white/60">
              <span className="ufc-mono">{record}</span>
              <span>·</span>
              <span>{flagEmoji(fighter.countryCode)}</span>
              {fighter.rank ? (
                <span className="ufc-mono text-[#e8c46a]">#{fighter.rank}</span>
              ) : null}
            </div>
          </div>
        </div>
      </button>
    );
  }

  return (
    <button
      type="button"
      onClick={onClick}
      className={`ufc-button-press relative w-full overflow-hidden rounded-md border text-left transition-all
        ${selected
          ? "border-[#d20a0a] ufc-shadow-red"
          : "border-white/10 hover:border-[#d20a0a]/60 hover:-translate-y-0.5"
        }`}
    >
      {/* top strip — gold for champ, red for ranked, neutral otherwise */}
      <div className={`h-1 w-full ${fighter.isChampion ? "ufc-gold-grad" : fighter.rank ? "ufc-red-grad" : "bg-white/10"}`} />

      <div className="ufc-card-grain p-4">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className={`flex h-12 w-12 items-center justify-center rounded-full font-black text-white
              ${fighter.isChampion ? "ufc-gold-grad" : "ufc-red-grad"}`}>
              {initials}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-extrabold text-white leading-tight">
                  {fighter.name}
                </h3>
                {fighter.isChampion && (
                  <span className="ufc-tag ufc-gold-grad text-black">★ CHAMP</span>
                )}
              </div>
              {fighter.nickname && (
                <p className="text-xs italic text-[#e8c46a]/90">&ldquo;{fighter.nickname}&rdquo;</p>
              )}
              <div className="mt-0.5 flex items-center gap-2 text-xs text-white/60">
                <span>{flagEmoji(fighter.countryCode)}</span>
                <span>{fighter.country}</span>
                {fighter.rank ? (
                  <span className="ufc-mono text-[#e8c46a]">RANK #{fighter.rank}</span>
                ) : null}
              </div>
            </div>
          </div>
        </div>

        <div className="mt-3 grid grid-cols-3 gap-2 text-center">
          <div className="rounded bg-black/40 px-2 py-1.5">
            <div className="text-[10px] uppercase tracking-wider text-white/40">Record</div>
            <div className="ufc-mono text-sm font-bold text-white">{record}</div>
          </div>
          <div className="rounded bg-black/40 px-2 py-1.5">
            <div className="text-[10px] uppercase tracking-wider text-white/40">Class</div>
            <div className="text-sm font-bold text-white">{wc?.shortName}</div>
          </div>
          <div className="rounded bg-black/40 px-2 py-1.5">
            <div className="text-[10px] uppercase tracking-wider text-white/40">Style</div>
            <div className="text-sm font-bold text-white">{fighter.style}</div>
          </div>
        </div>

        <div className="mt-2 grid grid-cols-2 gap-2 text-[10px] text-white/70">
          <div className="flex justify-between rounded bg-black/30 px-2 py-1">
            <span className="uppercase tracking-wider text-white/40">Height</span>
            <span className="ufc-mono">{fighter.height}</span>
          </div>
          <div className="flex justify-between rounded bg-black/30 px-2 py-1">
            <span className="uppercase tracking-wider text-white/40">Reach</span>
            <span className="ufc-mono">{fighter.reach}</span>
          </div>
          <div className="flex justify-between rounded bg-black/30 px-2 py-1">
            <span className="uppercase tracking-wider text-white/40">Age</span>
            <span className="ufc-mono">{fighter.age}</span>
          </div>
          <div className="flex justify-between rounded bg-black/30 px-2 py-1">
            <span className="uppercase tracking-wider text-white/40">Team</span>
            <span className="truncate pl-2 text-right" title={fighter.team}>{fighter.team}</span>
          </div>
        </div>

        {fighter.winMethod && (
          <div className="mt-2 flex items-center justify-between rounded bg-[#d20a0a]/10 border border-[#d20a0a]/30 px-2 py-1">
            <span className="text-[10px] uppercase tracking-wider text-white/50">Finishes</span>
            <span className="ufc-mono text-xs font-bold text-[#ff8888]">{koSub} · {fighter.winMethod.dec} DEC</span>
          </div>
        )}
      </div>
    </button>
  );
}
