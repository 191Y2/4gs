"use client";

import { useState } from "react";
import { Bout, BoutType } from "@/lib/types";
import { getWeightClass } from "@/lib/weightClasses";
import { flagEmoji } from "@/lib/cardStore";
import { ChevronUp, ChevronDown, X, Crown, Star, MoreVertical } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface BoutRowProps {
  bout: Bout;
  compact?: boolean;
  isMainEvent?: boolean;
  onRemove: (id: string) => void;
  onMove: (id: string, dir: "up" | "down") => void;
  onTypeChange: (id: string, t: BoutType) => void;
}

export function BoutRow({ bout, compact, isMainEvent, onRemove, onMove, onTypeChange }: BoutRowProps) {
  const wc = getWeightClass(bout.weightClass);
  const [showAll, setShowAll] = useState(false);
  const a = bout.fighterA, b = bout.fighterB;
  const recA = `${a.record.wins}-${a.record.losses}-${a.record.draws}`;
  const recB = `${b.record.wins}-${b.record.losses}-${b.record.draws}`;

  return (
    <div className={`group relative ${isMainEvent ? "" : ""}`}>
      <div className="flex items-stretch gap-3">
        {/* Left side - Red corner */}
        <FighterSide fighter={a} color="red" record={recA} compact={compact} align="right" isMainEvent={isMainEvent} />

        {/* Center - VS / weight / options */}
        <div className="flex flex-col items-center justify-center min-w-[60px]">
          <div className="text-[9px] uppercase tracking-widest text-white/40">
            {bout.catchweight ? `${bout.catchweight} CW` : wc?.shortName}
          </div>
          <div className="ufc-text-gold ufc-headline text-base">VS</div>
          <div className="text-[9px] ufc-mono text-white/40">
            {bout.rounds}R
          </div>
          {bout.titleBout && (
            <div className="mt-0.5 ufc-tag ufc-gold-grad text-black" title="Title Bout">
              <Crown className="h-2.5 w-2.5" />
              TITLE
            </div>
          )}
          {bout.isFeatured && !bout.titleBout && (
            <div className="mt-0.5 ufc-tag bg-[#d20a0a] text-white" title="Featured">
              <Star className="h-2.5 w-2.5" />
              FEAT
            </div>
          )}
        </div>

        {/* Right side - Blue corner */}
        <FighterSide fighter={b} color="blue" record={recB} compact={compact} align="left" isMainEvent={isMainEvent} />

        {/* Controls */}
        <div className="flex flex-col justify-center opacity-0 group-hover:opacity-100 transition-opacity">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button size="sm" variant="ghost" className="h-7 w-7 p-0 text-white/40 hover:text-white hover:bg-white/5">
                <MoreVertical className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="bg-[#141414] border-white/10 text-white">
              <DropdownMenuItem onClick={() => onMove(bout.id, "up")} className="hover:bg-[#d20a0a]/30 hover:text-white cursor-pointer">
                <ChevronUp className="h-3.5 w-3.5 mr-2" /> Move Up
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => onMove(bout.id, "down")} className="hover:bg-[#d20a0a]/30 hover:text-white cursor-pointer">
                <ChevronDown className="h-3.5 w-3.5 mr-2" /> Move Down
              </DropdownMenuItem>
              <DropdownMenuSeparator className="bg-white/10" />
              <DropdownMenuItem onClick={() => onTypeChange(bout.id, "main-event")} className="hover:bg-[#d20a0a]/30 hover:text-white cursor-pointer">
                <Star className="h-3.5 w-3.5 mr-2 text-[#e8c46a]" /> Main Event
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => onTypeChange(bout.id, "co-main")} className="hover:bg-[#d20a0a]/30 hover:text-white cursor-pointer">
                <Star className="h-3.5 w-3.5 mr-2 text-white/60" /> Co-Main
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => onTypeChange(bout.id, "main-card")} className="hover:bg-[#d20a0a]/30 hover:text-white cursor-pointer">
                Main Card
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => onTypeChange(bout.id, "prelim")} className="hover:bg-[#d20a0a]/30 hover:text-white cursor-pointer">
                Prelim
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => onTypeChange(bout.id, "early-prelim")} className="hover:bg-[#d20a0a]/30 hover:text-white cursor-pointer">
                Early Prelim
              </DropdownMenuItem>
              <DropdownMenuSeparator className="bg-white/10" />
              <DropdownMenuItem onClick={() => onRemove(bout.id)} className="hover:bg-[#d20a0a]/40 hover:text-white cursor-pointer text-[#ff6666]">
                <X className="h-3.5 w-3.5 mr-2" /> Remove Bout
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </div>
  );
}

function FighterSide({
  fighter, color, record, compact, align, isMainEvent,
}: {
  fighter: Bout["fighterA"];
  color: "red" | "blue";
  record: string;
  compact?: boolean;
  align: "left" | "right";
  isMainEvent?: boolean;
}) {
  const accent = color === "red" ? "#d20a0a" : "#3b82f6";
  const initials = fighter.name.split(" ").map((p) => p[0]).slice(0, 2).join("");

  const nameSize = isMainEvent ? "text-xl md:text-2xl" : compact ? "text-sm" : "text-base md:text-lg";

  return (
    <div
      className={`flex-1 ${align === "right" ? "text-right" : "text-left"}`}
      style={{ borderLeft: align === "left" ? `1px solid ${accent}40` : undefined,
               borderRight: align === "right" ? `1px solid ${accent}40` : undefined }}
    >
      <div className={`flex items-center gap-2 ${align === "right" ? "flex-row-reverse" : ""}`}>
        <div
          className={`flex shrink-0 items-center justify-center rounded-full font-black text-white
            ${isMainEvent ? "h-12 w-12 md:h-14 md:w-14 text-base" : "h-9 w-9 text-xs"}`}
          style={{
            background: fighter.isChampion
              ? "linear-gradient(135deg, #e8c46a 0%, #8b6e2a 100%)"
              : `linear-gradient(135deg, ${accent} 0%, #1a1a1a 100%)`,
            boxShadow: `0 0 0 2px ${accent}60`,
          }}
        >
          {initials}
        </div>

        <div className={`min-w-0 flex-1 ${align === "right" ? "items-end" : "items-start"} flex flex-col`}>
          <div className={`flex items-center gap-1.5 ${align === "right" ? "flex-row-reverse" : ""}`}>
            <span className={`font-extrabold text-white leading-tight ufc-clamp-2 ${nameSize}`}>
              {fighter.name}
            </span>
            {fighter.isChampion && <Crown className="h-3.5 w-3.5 text-[#e8c46a] shrink-0" />}
          </div>

          {!compact && fighter.nickname && (
            <span className="text-[11px] italic text-white/50 leading-tight">
              &ldquo;{fighter.nickname}&rdquo;
            </span>
          )}

          <div className={`flex items-center gap-2 text-[10px] text-white/50 ${align === "right" ? "flex-row-reverse" : ""}`}>
            <span>{flagEmoji(fighter.countryCode)}</span>
            <span className="ufc-mono font-bold text-white/80">{record}</span>
            {fighter.rank && <span className="ufc-mono text-[#e8c46a]">#{fighter.rank}</span>}
            {!compact && (
              <span className="text-white/40 hidden sm:inline">
                · {fighter.height} · {fighter.reach} · {fighter.style}
              </span>
            )}
          </div>

          {!compact && fighter.winMethod && (
            <div className={`flex items-center gap-2 text-[9px] ufc-mono ${align === "right" ? "flex-row-reverse" : ""}`}>
              <span className="text-[#ff8888]">{fighter.winMethod.ko}KO</span>
              <span className="text-[#88ccff]">{fighter.winMethod.sub}SUB</span>
              <span className="text-white/40">{fighter.winMethod.dec}DEC</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
