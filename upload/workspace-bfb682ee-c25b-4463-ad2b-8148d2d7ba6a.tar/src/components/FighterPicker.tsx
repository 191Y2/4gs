"use client";

import { useMemo, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Search, X, Crown, Star } from "lucide-react";
import { FIGHTERS, searchFighters } from "@/lib/fighters";
import { Fighter, WeightClassId } from "@/lib/types";
import { WEIGHT_CLASSES } from "@/lib/weightClasses";
import { FighterCard } from "./FighterCard";

interface FighterPickerProps {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  title: string;
  excludeIds?: string[];
  preferredWeightClass?: WeightClassId;
  onSelect: (f: Fighter) => void;
}

export function FighterPicker({
  open,
  onOpenChange,
  title,
  excludeIds = [],
  preferredWeightClass,
  onSelect,
}: FighterPickerProps) {
  const [query, setQuery] = useState("");
  const [division, setDivision] = useState<"men" | "women">(
    preferredWeightClass
      ? (WEIGHT_CLASSES.find((w) => w.id === preferredWeightClass)?.division ?? "men")
      : "men"
  );
  const [wc, setWc] = useState<WeightClassId | "ALL">(
    preferredWeightClass || "ALL"
  );
  const [filter, setFilter] = useState<"all" | "ranked" | "champ">("all");

  const filtered = useMemo(() => {
    let list = searchFighters(query, wc === "ALL" ? undefined : wc);
    list = list.filter((f) => f.weightClass && WEIGHT_CLASSES.find((w) => w.id === f.weightClass)?.division === division);
    if (filter === "ranked") list = list.filter((f) => f.rank && f.rank > 0);
    if (filter === "champ") list = list.filter((f) => f.isChampion);
    // exclude already-picked fighters in current card
    list = list.filter((f) => !excludeIds.includes(f.id));
    // sort: champs first, then rank, then alphabetical
    list.sort((a, b) => {
      if (a.isChampion && !b.isChampion) return -1;
      if (!a.isChampion && b.isChampion) return 1;
      const ra = a.rank || 99, rb = b.rank || 99;
      if (ra !== rb) return ra - rb;
      return a.name.localeCompare(b.name);
    });
    return list;
  }, [query, wc, division, filter, excludeIds]);

  const totalRoster = FIGHTERS.length;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent
        aria-describedby={undefined}
        className="max-w-5xl h-[88vh] p-0 gap-0 overflow-hidden bg-[#0a0a0a] border-[#d20a0a]/30 text-white"
      >
        <div className="ufc-strip h-1.5 w-full" />
        <DialogHeader className="px-5 pt-4 pb-3 border-b border-white/10">
          <DialogTitle className="ufc-headline flex items-center gap-2 text-xl text-white">
            <span className="ufc-red-grad inline-flex h-7 w-7 items-center justify-center rounded text-xs">UFC</span>
            {title}
            <span className="ml-auto text-[10px] font-mono text-white/40 tracking-wider">
              ROSTER · {totalRoster} FIGHTERS
            </span>
          </DialogTitle>
        </DialogHeader>

        {/* Controls */}
        <div className="border-b border-white/10 px-5 py-3 space-y-3 bg-black/40">
          <div className="flex items-center gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-white/40" />
              <Input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search name, nickname, country, team..."
                className="pl-9 bg-[#141414] border-white/10 text-white placeholder:text-white/30 focus:border-[#d20a0a]"
              />
            </div>
            {query && (
              <Button
                size="sm"
                variant="ghost"
                onClick={() => setQuery("")}
                className="text-white/60 hover:text-white"
              >
                <X className="h-4 w-4" />
              </Button>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <Tabs value={division} onValueChange={(v) => { setDivision(v as "men" | "women"); setWc("ALL"); }}>
              <TabsList className="bg-[#141414] border border-white/10">
                <TabsTrigger value="men" className="data-[state=active]:bg-[#d20a0a] data-[state=active]:text-white text-white/70">
                  MEN
                </TabsTrigger>
                <TabsTrigger value="women" className="data-[state=active]:bg-[#d20a0a] data-[state=active]:text-white text-white/70">
                  WOMEN
                </TabsTrigger>
              </TabsList>
            </Tabs>

            <div className="flex flex-wrap gap-1">
              <Button
                size="sm"
                variant={wc === "ALL" ? "default" : "ghost"}
                onClick={() => setWc("ALL")}
                className={wc === "ALL"
                  ? "bg-[#d20a0a] hover:bg-[#8b0606] text-white h-7 text-xs"
                  : "text-white/60 hover:text-white h-7 text-xs"}
              >
                ALL WEIGHTS
              </Button>
              {WEIGHT_CLASSES.filter((w) => w.division === division).map((w) => (
                <Button
                  key={w.id}
                  size="sm"
                  variant={wc === w.id ? "default" : "ghost"}
                  onClick={() => setWc(w.id)}
                  className={wc === w.id
                    ? "bg-[#d20a0a] hover:bg-[#8b0606] text-white h-7 text-xs"
                    : "text-white/60 hover:text-white h-7 text-xs"}
                >
                  {w.shortName}
                </Button>
              ))}
            </div>

            <div className="ml-auto flex items-center gap-1">
              <Button
                size="sm"
                variant={filter === "all" ? "default" : "ghost"}
                onClick={() => setFilter("all")}
                className={filter === "all"
                  ? "bg-white text-black h-7 text-xs"
                  : "text-white/60 hover:text-white h-7 text-xs"}
              >
                ALL
              </Button>
              <Button
                size="sm"
                variant={filter === "ranked" ? "default" : "ghost"}
                onClick={() => setFilter("ranked")}
                className={filter === "ranked"
                  ? "bg-[#d20a0a] hover:bg-[#8b0606] text-white h-7 text-xs"
                  : "text-white/60 hover:text-white h-7 text-xs"}
              >
                <Star className="h-3 w-3 mr-1" /> RANKED
              </Button>
              <Button
                size="sm"
                variant={filter === "champ" ? "default" : "ghost"}
                onClick={() => setFilter("champ")}
                className={filter === "champ"
                  ? "ufc-gold-grad text-black hover:opacity-90 h-7 text-xs"
                  : "text-white/60 hover:text-white h-7 text-xs"}
              >
                <Crown className="h-3 w-3 mr-1" /> CHAMPS
              </Button>
            </div>
          </div>
        </div>

        {/* Fighter grid */}
        <ScrollArea className="flex-1 px-5 py-4 ufc-scroll-thin">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 pb-6">
            {filtered.map((f) => (
              <FighterCard
                key={f.id}
                fighter={f}
                onClick={() => { onSelect(f); onOpenChange(false); }}
              />
            ))}
            {filtered.length === 0 && (
              <div className="col-span-full text-center py-20 text-white/40">
                <p className="text-lg">No fighters match your filters.</p>
                <p className="text-sm mt-2">Try clearing the search or switching weight class.</p>
              </div>
            )}
          </div>
        </ScrollArea>

        <div className="border-t border-white/10 bg-black/60 px-5 py-2 flex items-center justify-between">
          <span className="ufc-mono text-xs text-white/40">
            SHOWING {filtered.length} / {totalRoster}
          </span>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onOpenChange(false)}
            className="text-white/60 hover:text-white"
          >
            Close
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
