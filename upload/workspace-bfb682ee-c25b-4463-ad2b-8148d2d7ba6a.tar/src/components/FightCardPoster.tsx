"use client";

import { Bout } from "@/lib/types";
import { getWeightClass } from "@/lib/weightClasses";
import { flagEmoji, useCardStore } from "@/lib/cardStore";
import { BoutRow } from "./BoutRow";

export function FightCardPoster() {
  const { card, clearCard, moveBout, removeBout, setBoutType } = useCardStore();

  const mainEvent = card.bouts.find((b) => b.boutType === "main-event") || card.bouts[0];
  const coMain = card.bouts.find((b) => b.boutType === "co-main");
  const mainCard = card.bouts.filter((b) => b.boutType === "main-card");
  const prelims = card.bouts.filter((b) => b.boutType === "prelim");
  const earlyPrelims = card.bouts.filter((b) => b.boutType === "early-prelim");

  const eventDate = new Date(card.date + "T19:00:00");
  const dateStr = eventDate.toLocaleDateString("en-US", {
    weekday: "short", month: "short", day: "numeric", year: "numeric",
  });

  const location = [card.city, card.state, card.country].filter(Boolean).join(", ");

  return (
    <div className="ufc-poster-frame rounded-lg overflow-hidden">
      {/* ========== POSTER HEADER ========== */}
      <div className="relative ufc-strip h-2 w-full" />

      <div className="relative px-6 pt-6 pb-4 ufc-card-grain">
        {/* Background glow */}
        <div className="absolute inset-0 pointer-events-none opacity-30"
          style={{ background: "radial-gradient(circle at 50% 0%, #d20a0a50, transparent 60%)" }}
        />

        <div className="relative flex items-center justify-between gap-3 mb-3">
          <div className="flex items-center gap-3">
            <div className="ufc-red-grad px-2.5 py-1.5 rounded-sm">
              <span className="ufc-headline text-xl font-black text-white leading-none tracking-tighter">
                {card.promotion || "UFC"}
              </span>
            </div>
            <div className="h-8 w-px bg-white/20" />
            <div>
              <div className="ufc-tag bg-white/10 text-[#e8c46a]">
                LIVE · PAY-PER-VIEW
              </div>
              <div className="text-[10px] text-white/40 mt-0.5 ufc-mono tracking-widest">
                FIGHT NIGHT EXECUTIVE
              </div>
            </div>
          </div>

          <div className="text-right">
            <div className="ufc-mono text-[10px] text-white/50 tracking-widest">EVENT DATE</div>
            <div className="text-sm font-black text-white">{dateStr}</div>
          </div>
        </div>

        {/* Event title */}
        <div className="relative">
          <h1 className="ufc-headline text-5xl sm:text-6xl lg:text-7xl font-black text-white leading-[0.85] tracking-tighter">
            {card.eventName.toUpperCase()}
          </h1>
          {card.tagline && (
            <div className="mt-2 flex items-center gap-3">
              <div className="h-px flex-1 ufc-octagon-divider" />
              <span className="ufc-tag ufc-gold-grad text-black">
                {card.tagline}
              </span>
              <div className="h-px flex-1 ufc-octagon-divider" />
            </div>
          )}
        </div>

        {/* Venue / Location */}
        <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-2">
          <div className="flex items-center gap-2 rounded border border-white/10 bg-black/40 px-3 py-2">
            <span className="ufc-tag bg-[#d20a0a] text-white">VENUE</span>
            <span className="text-sm font-bold text-white truncate">{card.venue}</span>
          </div>
          <div className="flex items-center gap-2 rounded border border-white/10 bg-black/40 px-3 py-2">
            <span className="ufc-tag ufc-gold-grad text-black">LOCATION</span>
            <span className="text-sm font-bold text-white truncate">{location}</span>
          </div>
        </div>
      </div>

      {/* ========== MAIN EVENT ========== */}
      {mainEvent && (
        <div className="relative bg-black">
          <div className="px-6 py-3 flex items-center gap-3 border-t border-b border-[#d20a0a]/30 bg-gradient-to-r from-[#d20a0a]/20 via-black to-[#d20a0a]/20">
            <span className="ufc-tag ufc-red-grad text-white">★ MAIN EVENT</span>
            <div className="h-px flex-1 bg-gradient-to-r from-[#d20a0a] to-transparent" />
            <span className="text-[10px] ufc-mono text-white/60 tracking-widest">
              {mainEvent.titleBout ? "5 ROUNDS · CHAMPIONSHIP" : `${mainEvent.rounds} ROUNDS`}
            </span>
          </div>
          <div className="px-6 py-5">
            <BoutRow bout={mainEvent} isMainEvent onRemove={removeBout} onMove={moveBout} onTypeChange={setBoutType} />
          </div>
        </div>
      )}

      {/* ========== CO-MAIN ========== */}
      {coMain && (
        <div className="relative bg-black">
          <div className="px-6 py-2 flex items-center gap-3 border-t border-b border-white/10 bg-gradient-to-r from-[#e8c46a]/10 to-transparent">
            <span className="ufc-tag ufc-gold-grad text-black">CO-MAIN EVENT</span>
            <div className="h-px flex-1 bg-gradient-to-r from-[#e8c46a]/50 to-transparent" />
            <span className="text-[10px] ufc-mono text-white/60 tracking-widest">
              {coMain.rounds} ROUNDS
            </span>
          </div>
          <div className="px-6 py-4">
            <BoutRow bout={coMain} onRemove={removeBout} onMove={moveBout} onTypeChange={setBoutType} />
          </div>
        </div>
      )}

      {/* ========== MAIN CARD ========== */}
      {mainCard.length > 0 && (
        <div className="relative bg-black">
          <div className="px-6 py-2 flex items-center gap-3 border-t border-white/10 bg-white/[0.02]">
            <span className="ufc-tag bg-white/10 text-white">MAIN CARD</span>
            <span className="text-[10px] ufc-mono text-white/40 tracking-widest">
              PPV · {mainCard.length} {mainCard.length === 1 ? "BOUT" : "BOUTS"}
            </span>
            <div className="h-px flex-1 bg-white/10" />
          </div>
          <div className="divide-y divide-white/[0.04]">
            {mainCard.map((b) => (
              <div key={b.id} className="px-6 py-3">
                <BoutRow bout={b} onRemove={removeBout} onMove={moveBout} onTypeChange={setBoutType} />
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ========== PRELIMS ========== */}
      {prelims.length > 0 && (
        <div className="relative bg-black">
          <div className="px-6 py-2 flex items-center gap-3 border-t border-white/10 bg-white/[0.02]">
            <span className="ufc-tag bg-[#3b82f6]/20 text-[#88ccff]">PRELIMS</span>
            <span className="text-[10px] ufc-mono text-white/40 tracking-widest">
              ESPN+ · {prelims.length} {prelims.length === 1 ? "BOUT" : "BOUTS"}
            </span>
            <div className="h-px flex-1 bg-white/10" />
          </div>
          <div className="divide-y divide-white/[0.04]">
            {prelims.map((b) => (
              <div key={b.id} className="px-6 py-3">
                <BoutRow bout={b} compact onRemove={removeBout} onMove={moveBout} onTypeChange={setBoutType} />
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ========== EARLY PRELIMS ========== */}
      {earlyPrelims.length > 0 && (
        <div className="relative bg-black">
          <div className="px-6 py-2 flex items-center gap-3 border-t border-white/10 bg-white/[0.02]">
            <span className="ufc-tag bg-white/5 text-white/60">EARLY PRELIMS</span>
            <span className="text-[10px] ufc-mono text-white/40 tracking-widest">
              UFC FIGHT PASS · {earlyPrelims.length} {earlyPrelims.length === 1 ? "BOUT" : "BOUTS"}
            </span>
            <div className="h-px flex-1 bg-white/10" />
          </div>
          <div className="divide-y divide-white/[0.04]">
            {earlyPrelims.map((b) => (
              <div key={b.id} className="px-6 py-3">
                <BoutRow bout={b} compact onRemove={removeBout} onMove={moveBout} onTypeChange={setBoutType} />
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ========== EMPTY STATE ========== */}
      {card.bouts.length === 0 && (
        <div className="px-6 py-16 text-center">
          <div className="mx-auto mb-4 h-20 w-20 rounded-full border-2 border-dashed border-white/20 flex items-center justify-center">
            <span className="text-3xl">🥊</span>
          </div>
          <h3 className="ufc-headline text-2xl text-white">No Bouts Yet</h3>
          <p className="text-sm text-white/50 mt-2 max-w-md mx-auto">
            Use the Bout Builder above to pick two fighters and add the first fight to your card.
            The first bout you add automatically becomes the Main Event.
          </p>
        </div>
      )}

      {/* ========== FOOTER ========== */}
      <div className="border-t border-white/10 ufc-strip h-1.5" />
      <div className="bg-black px-6 py-3 flex items-center justify-between text-[10px] ufc-mono text-white/40 tracking-widest">
        <span>{card.promotion} · FIGHT CARD GENERATED · {card.bouts.length} BOUTS</span>
        <span>BUILT WITH UFC CARD CREATOR</span>
      </div>
    </div>
  );
}
