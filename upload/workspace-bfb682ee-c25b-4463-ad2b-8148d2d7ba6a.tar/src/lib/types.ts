export type WeightClassId =
  | "HW"
  | "LHW"
  | "MW"
  | "WW"
  | "LW"
  | "FW"
  | "BW"
  | "FLW"
  | "WBW"
  | "WFLW"
  | "WSW"
  | "WFW";

export interface WeightClass {
  id: WeightClassId;
  name: string;
  shortName: string;
  limit: number; // lbs
  division: "men" | "women";
}

export interface Fighter {
  id: string;
  name: string;
  nickname?: string;
  weightClass: WeightClassId;
  rank?: number; // 1-15, undefined = unranked
  isChampion?: boolean;
  isInterimChampion?: boolean;
  country: string;
  countryCode: string; // ISO-2
  height?: string; // e.g. "5'11\""
  reach?: string; // e.g. "74\""
  age?: number;
  team?: string;
  style?: string; // Striker, Grappler, MMA, Boxer, etc.
  record: {
    wins: number;
    losses: number;
    draws: number;
    nc?: number; // no contests
  };
  winMethod?: {
    ko: number;
    sub: number;
    dec: number;
  };
  status?: "active" | "injured" | "suspended" | "retired";
}

export interface Bout {
  id: string;
  fighterA: Fighter;
  fighterB: Fighter;
  weightClass: WeightClassId;
  catchweight?: number; // lbs, if applicable
  rounds: number; // 3 or 5
  boutType: BoutType;
  titleBout?: {
    type: "undisputed" | "interim" | "vacant";
    weightClass: WeightClassId;
  };
  isFeatured?: boolean; // for "Feature Bout" tagging
  notes?: string;
}

export type BoutType =
  | "main-event"
  | "co-main"
  | "main-card"
  | "prelim"
  | "early-prelim";

export interface FightCard {
  eventName: string;
  tagline?: string;
  date: string; // ISO date
  venue: string;
  city: string;
  state?: string;
  country: string;
  promotion: string; // default "UFC"
  bouts: Bout[];
}
