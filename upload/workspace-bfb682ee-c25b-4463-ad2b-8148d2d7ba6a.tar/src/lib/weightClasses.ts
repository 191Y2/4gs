import { WeightClass } from "./types";

export const WEIGHT_CLASSES: WeightClass[] = [
  { id: "HW", name: "Heavyweight", shortName: "HW", limit: 265, division: "men" },
  { id: "LHW", name: "Light Heavyweight", shortName: "LHW", limit: 205, division: "men" },
  { id: "MW", name: "Middleweight", shortName: "MW", limit: 185, division: "men" },
  { id: "WW", name: "Welterweight", shortName: "WW", limit: 170, division: "men" },
  { id: "LW", name: "Lightweight", shortName: "LW", limit: 155, division: "men" },
  { id: "FW", name: "Featherweight", shortName: "FW", limit: 145, division: "men" },
  { id: "BW", name: "Bantamweight", shortName: "BW", limit: 135, division: "men" },
  { id: "FLW", name: "Flyweight", shortName: "FLW", limit: 125, division: "men" },
  { id: "WFW", name: "Women's Featherweight", shortName: "WFW", limit: 145, division: "women" },
  { id: "WBW", name: "Women's Bantamweight", shortName: "WBW", limit: 135, division: "women" },
  { id: "WFLW", name: "Women's Flyweight", shortName: "WFLW", limit: 125, division: "women" },
  { id: "WSW", name: "Women's Strawweight", shortName: "WSW", limit: 115, division: "women" },
];

export function getWeightClass(id: string): WeightClass | undefined {
  return WEIGHT_CLASSES.find((w) => w.id === id);
}

export function weightClassGradient(id: string): string {
  const map: Record<string, string> = {
    HW: "from-red-950 via-red-900 to-zinc-950",
    LHW: "from-orange-950 via-red-900 to-zinc-950",
    MW: "from-amber-950 via-orange-900 to-zinc-950",
    WW: "from-yellow-900 via-amber-800 to-zinc-950",
    LW: "from-lime-900 via-emerald-900 to-zinc-950",
    FW: "from-emerald-900 via-teal-900 to-zinc-950",
    BW: "from-cyan-900 via-sky-900 to-zinc-950",
    FLW: "from-sky-900 via-indigo-900 to-zinc-950",
    WFW: "from-fuchsia-950 via-rose-900 to-zinc-950",
    WBW: "from-rose-900 via-red-900 to-zinc-950",
    WFLW: "from-pink-900 via-fuchsia-900 to-zinc-950",
    WSW: "from-violet-900 via-purple-900 to-zinc-950",
  };
  return map[id] || "from-zinc-900 to-zinc-950";
}
