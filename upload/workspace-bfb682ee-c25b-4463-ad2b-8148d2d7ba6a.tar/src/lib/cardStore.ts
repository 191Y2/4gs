"use client";

import { create } from "zustand";
import { persist } from "zustand/middleware";
import { v4 as uuidv4 } from "uuid";
import { Bout, BoutType, FightCard, Fighter, WeightClassId } from "./types";

interface CardStore {
  card: FightCard;
  selectedFighterA: Fighter | null;
  selectedFighterB: Fighter | null;

  // Card meta
  setEventName: (name: string) => void;
  setTagline: (t: string) => void;
  setDate: (d: string) => void;
  setVenue: (v: string) => void;
  setCity: (c: string) => void;
  setState: (s: string) => void;
  setCountry: (c: string) => void;
  setPromotion: (p: string) => void;

  // Bout building
  setSelectedA: (f: Fighter | null) => void;
  setSelectedB: (f: Fighter | null) => void;
  addBout: (config?: Partial<Bout>) => void;
  removeBout: (id: string) => void;
  moveBout: (id: string, dir: "up" | "down") => void;
  updateBout: (id: string, patch: Partial<Bout>) => void;
  setBoutType: (id: string, t: BoutType) => void;

  // Card actions
  clearCard: () => void;
  loadCard: (c: FightCard) => void;
}

const todayPlus = (days: number) => {
  const d = new Date();
  d.setDate(d.getDate() + days);
  return d.toISOString().slice(0, 10);
};

const DEFAULT_CARD: FightCard = {
  eventName: "UFC 312",
  tagline: "Title Unification",
  date: todayPlus(21),
  venue: "Qudos Bank Arena",
  city: "Sydney",
  state: "NSW",
  country: "Australia",
  promotion: "UFC",
  bouts: [],
};

export const useCardStore = create<CardStore>()(
  persist(
    (set, get) => ({
      card: DEFAULT_CARD,
      selectedFighterA: null,
      selectedFighterB: null,

      setEventName: (name) => set((s) => ({ card: { ...s.card, eventName: name } })),
      setTagline: (t) => set((s) => ({ card: { ...s.card, tagline: t } })),
      setDate: (d) => set((s) => ({ card: { ...s.card, date: d } })),
      setVenue: (v) => set((s) => ({ card: { ...s.card, venue: v } })),
      setCity: (c) => set((s) => ({ card: { ...s.card, city: c } })),
      setState: (st) => set((s) => ({ card: { ...s.card, state: st } })),
      setCountry: (c) => set((s) => ({ card: { ...s.card, country: c } })),
      setPromotion: (p) => set((s) => ({ card: { ...s.card, promotion: p } })),

      setSelectedA: (f) => set({ selectedFighterA: f }),
      setSelectedB: (f) => set({ selectedFighterB: f }),

      addBout: (config) => {
        const a = get().selectedFighterA;
        const b = get().selectedFighterB;
        if (!a || !b) return;

        const weightClass = config?.weightClass || a.weightClass;
        const isTitle =
          config?.titleBout !== undefined
            ? !!config?.titleBout
            : a.isChampion || b.isChampion;

        const titleBout = isTitle
          ? {
              type: a.isChampion || b.isChampion ? ("undisputed" as const) : ("vacant" as const),
              weightClass,
            }
          : undefined;

        const newBout: Bout = {
          id: uuidv4(),
          fighterA: a,
          fighterB: b,
          weightClass,
          catchweight: config?.catchweight,
          rounds: isTitle ? 5 : 3,
          boutType: config?.boutType || "prelim",
          titleBout,
          isFeatured: config?.isFeatured,
          notes: config?.notes,
        };

        set((s) => ({
          card: { ...s.card, bouts: [...s.card.bouts, newBout] },
          selectedFighterA: null,
          selectedFighterB: null,
        }));
      },

      removeBout: (id) =>
        set((s) => ({ card: { ...s.card, bouts: s.card.bouts.filter((b) => b.id !== id) } })),

      moveBout: (id, dir) =>
        set((s) => {
          const bouts = [...s.card.bouts];
          const i = bouts.findIndex((b) => b.id === id);
          if (i === -1) return s;
          const j = dir === "up" ? i - 1 : i + 1;
          if (j < 0 || j >= bouts.length) return s;
          [bouts[i], bouts[j]] = [bouts[j], bouts[i]];
          return { card: { ...s.card, bouts } };
        }),

      updateBout: (id, patch) =>
        set((s) => ({
          card: {
            ...s.card,
            bouts: s.card.bouts.map((b) => (b.id === id ? { ...b, ...patch } : b)),
          },
        })),

      setBoutType: (id, t) =>
        set((s) => ({
          card: {
            ...s.card,
            bouts: s.card.bouts.map((b) => (b.id === id ? { ...b, boutType: t } : b)),
          },
        })),

      clearCard: () => set((s) => ({ card: { ...s.card, bouts: [] } })),
      loadCard: (c) => set({ card: c }),
    }),
    {
      name: "ufc-card-creator",
      partialize: (s) => ({ card: s.card }),
    }
  )
);

export function flagEmoji(countryCode: string): string {
  if (!countryCode || countryCode.length !== 2) return "🏳️";
  const cc = countryCode.toUpperCase();
  const A = 0x1f1e6;
  const codePoints = Array.from(cc).map((c) => A + (c.charCodeAt(0) - 65));
  return String.fromCodePoint(...codePoints);
}
