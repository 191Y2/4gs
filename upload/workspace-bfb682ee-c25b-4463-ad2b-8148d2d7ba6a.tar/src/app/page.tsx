"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { useCardStore } from "@/lib/cardStore";
import { BoutBuilder } from "@/components/BoutBuilder";
import { EventHeaderEditor } from "@/components/EventHeaderEditor";
import { FightCardPoster } from "@/components/FightCardPoster";
import { RosterStats } from "@/components/RosterStats";
import { FighterPicker } from "@/components/FighterPicker";
import { FIGHTERS } from "@/lib/fighters";
import { Fighter } from "@/lib/types";
import { Swords, Trash2, Download, Share2, Shuffle, Plus, Search, Eye } from "lucide-react";
import { toast } from "sonner";

export default function Home() {
  const { card, clearCard, loadCard } = useCardStore();
  const [rosterOpen, setRosterOpen] = useState(false);

  const boutCount = card.bouts.length;
  const totalFights = boutCount;

  const handleClear = () => {
    if (boutCount === 0) return;
    if (confirm("Clear all bouts from the card? This cannot be undone.")) {
      clearCard();
      toast.success("Card cleared");
    }
  };

  const handleExport = () => {
    const data = JSON.stringify(card, null, 2);
    const blob = new Blob([data], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${card.eventName.replace(/\s+/g, "-").toLowerCase()}-card.json`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success("Card exported as JSON");
  };

  const handleShare = async () => {
    const text = formatCardForShare(card);
    try {
      if (navigator.share) {
        await navigator.share({ title: card.eventName, text });
        return;
      }
      await navigator.clipboard.writeText(text);
      toast.success("Card copied to clipboard");
    } catch {
      toast.error("Could not share card");
    }
  };

  // Auto-fill a sample card from the roster for demo purposes
  const handleAutoFill = () => {
    const champs = FIGHTERS.filter((f) => f.isChampion).slice(0, 5);
    if (champs.length === 0) return;
    const newBouts = champs.map((champ, i) => {
      const contenders = FIGHTERS
        .filter((f) => f.weightClass === champ.weightClass && f.rank && f.rank <= 5 && !f.isChampion)
        .slice(0, 5);
      const opponent = contenders[Math.floor(Math.random() * contenders.length)] || champs[(i + 1) % champs.length];
      return {
        id: crypto.randomUUID(),
        fighterA: champ,
        fighterB: opponent,
        weightClass: champ.weightClass,
        rounds: 5,
        boutType: i === 0 ? "main-event" as const : i === 1 ? "co-main" as const : "main-card" as const,
        titleBout: { type: "undisputed" as const, weightClass: champ.weightClass },
      };
    });
    loadCard({ ...card, bouts: newBouts });
    toast.success(`Auto-filled ${newBouts.length} championship bouts`);
  };

  return (
    <div className="ufc-app ufc-octagon-bg min-h-screen">
      {/* Sticky top bar */}
      <header className="sticky top-0 z-40 border-b border-white/10 bg-black/70 backdrop-blur-md">
        <div className="ufc-strip h-1 w-full" />
        <div className="max-w-[1600px] mx-auto px-4 sm:px-6 py-3 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="ufc-red-grad px-2.5 py-1.5 rounded-sm">
              <span className="ufc-headline text-lg font-black text-white leading-none tracking-tighter">UFC</span>
            </div>
            <div>
              <h1 className="ufc-headline text-sm sm:text-base font-black text-white leading-none">
                CARD CREATOR
              </h1>
              <p className="text-[9px] sm:text-[10px] text-white/40 ufc-mono tracking-widest uppercase">
                Text-Based Promotion Engine · {FIGHTERS.length} fighters
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 sm:gap-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setRosterOpen(true)}
              className="text-white/70 hover:text-white hover:bg-white/5"
            >
              <Search className="h-4 w-4 mr-1" />
              <span className="hidden sm:inline">Roster</span>
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleAutoFill}
              className="text-white/70 hover:text-white hover:bg-white/5"
              title="Auto-fill a championship card"
            >
              <Shuffle className="h-4 w-4 mr-1" />
              <span className="hidden sm:inline">Auto-Fill</span>
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleShare}
              className="text-white/70 hover:text-white hover:bg-white/5"
            >
              <Share2 className="h-4 w-4 mr-1" />
              <span className="hidden sm:inline">Share</span>
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleExport}
              className="text-white/70 hover:text-white hover:bg-white/5"
            >
              <Download className="h-4 w-4 mr-1" />
              <span className="hidden sm:inline">Export</span>
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleClear}
              className="text-[#ff6666] hover:text-white hover:bg-[#d20a0a]/30"
            >
              <Trash2 className="h-4 w-4 mr-1" />
              <span className="hidden sm:inline">Clear</span>
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-[1600px] mx-auto px-4 sm:px-6 py-6">
        {/* Hero strip */}
        <div className="mb-6 rounded-lg overflow-hidden border border-white/10 ufc-card-grain">
          <div className="px-6 py-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <Swords className="h-5 w-5 text-[#d20a0a]" />
                <span className="ufc-tag bg-[#d20a0a] text-white">FIGHT ENGINE v2.6</span>
              </div>
              <h2 className="ufc-headline text-2xl sm:text-3xl font-black text-white">
                BUILD YOUR <span className="ufc-text-red">ULTIMATE</span> FIGHT CARD
              </h2>
              <p className="text-sm text-white/50 mt-1 max-w-2xl">
                Hand-pick from {FIGHTERS.length}+ real UFC fighters across all 12 weight classes.
                Arrange bouts, set title fights, customize your event details, and export a poster-ready fight card.
              </p>
            </div>
            <div className="flex items-center gap-4 shrink-0">
              <div className="text-center">
                <div className="ufc-mono text-3xl font-black text-[#d20a0a]">{totalFights}</div>
                <div className="text-[10px] uppercase tracking-widest text-white/40">Bouts</div>
              </div>
              <div className="h-10 w-px bg-white/10" />
              <div className="text-center">
                <div className="ufc-mono text-3xl font-black text-[#e8c46a]">
                  {card.bouts.filter((b) => b.titleBout).length}
                </div>
                <div className="text-[10px] uppercase tracking-widest text-white/40">Titles</div>
              </div>
              <div className="h-10 w-px bg-white/10" />
              <div className="text-center">
                <div className="ufc-mono text-3xl font-black text-white">
                  {FIGHTERS.filter((f) => f.isChampion).length}
                </div>
                <div className="text-[10px] uppercase tracking-widest text-white/40">Champs</div>
              </div>
            </div>
          </div>
        </div>

        {/* Main layout: builder column + poster column */}
        <div className="grid grid-cols-1 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.4fr)] gap-6">
          {/* LEFT: Builder */}
          <div className="space-y-4">
            <EventHeaderEditor />
            <BoutBuilder />
            <RosterStats />
          </div>

          {/* RIGHT: Fight card poster */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="ufc-headline text-sm tracking-widest text-white/70 flex items-center gap-2">
                <Eye className="h-4 w-4 text-[#d20a0a]" />
                FIGHT CARD PREVIEW
              </h2>
              <div className="flex items-center gap-2 text-[10px] ufc-mono text-white/40">
                <span className="inline-block h-2 w-2 rounded-full bg-[#d20a0a] animate-pulse" />
                LIVE PREVIEW
              </div>
            </div>
            <FightCardPoster />
          </div>
        </div>
      </main>

      <footer className="mt-auto border-t border-white/10 bg-black/60 py-4">
        <div className="max-w-[1600px] mx-auto px-4 sm:px-6 flex items-center justify-between text-[10px] ufc-mono text-white/30 tracking-widest">
          <span>UFC CARD CREATOR · UNOFFICIAL FAN TOOL · {FIGHTERS.length} FIGHTERS</span>
          <span>NOT AFFILIATED WITH UFC · Z.AI BUILD</span>
        </div>
      </footer>

      {/* Roster browser modal */}
      <FighterPicker
        open={rosterOpen}
        onOpenChange={setRosterOpen}
        title="Browse Full Roster"
        onSelect={(f: Fighter) => {
          toast.info(`${f.name} · ${f.record.wins}-${f.record.losses}-${f.record.draws}`);
        }}
      />
    </div>
  );
}

function formatCardForShare(card: ReturnType<typeof useCardStore.getState>["card"]): string {
  const lines: string[] = [];
  lines.push(`🥊 ${card.eventName.toUpperCase()} 🥊`);
  if (card.tagline) lines.push(`"${card.tagline}"`);
  lines.push(`📅 ${card.date} · 📍 ${card.venue}, ${card.city}, ${card.country}`);
  lines.push("");
  card.bouts.forEach((b, i) => {
    const tag = b.boutType === "main-event" ? "【MAIN EVENT】"
      : b.boutType === "co-main" ? "【CO-MAIN】"
      : b.boutType === "prelim" ? "[Prelim]"
      : b.boutType === "early-prelim" ? "[Early Prelim]"
      : "[Main Card]";
    const titleTag = b.titleBout ? " 🏆 TITLE" : "";
    lines.push(`${tag}${titleTag}  ${b.fighterA.name} (${b.fighterA.record.wins}-${b.fighterA.record.losses}) VS ${b.fighterB.name} (${b.fighterB.record.wins}-${b.fighterB.record.losses})`);
    if (i === card.bouts.length - 1) lines.push("");
  });
  lines.push(`— Built with UFC Card Creator`);
  return lines.join("\n");
}
