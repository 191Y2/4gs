import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "UFC Card Creator — Build Your Ultimate Fight Card",
  description: "Text-based UFC fight card builder with hundreds of real UFC fighters across all 12 weight classes. Build, customize, and export your dream fight card.",
  keywords: ["UFC", "MMA", "fight card", "UFC roster", "fight predictor", "Z.ai"],
  authors: [{ name: "Z.ai Team" }],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
  openGraph: {
    title: "UFC Card Creator",
    description: "Build your dream UFC fight card with hundreds of real fighters.",
    url: "https://chat.z.ai",
    siteName: "Z.ai",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "UFC Card Creator",
    description: "Build your dream UFC fight card with hundreds of real fighters.",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
        <Sonner position="bottom-right" theme="dark" richColors closeButton />
      </body>
    </html>
  );
}
